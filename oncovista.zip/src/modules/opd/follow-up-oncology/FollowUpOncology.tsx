export default function FollowUpOncology() {
  return (
    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
      <li>3-monthly imaging and bloods</li>
      <li>Tumor markers (CEA, CA-125, PSA)</li>
      <li>Late toxicity / recurrence surveillance</li>
    </ul>
  );
}
