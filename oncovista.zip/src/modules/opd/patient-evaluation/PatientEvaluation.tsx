export default function PatientEvaluation() {
  return (
    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
      <li>Comprehensive physical exam</li>
      <li>Performance Status: ECOG / Karnofsky</li>
      <li>Note: “Cachectic, ECOG 2”</li>
    </ul>
  );
}
