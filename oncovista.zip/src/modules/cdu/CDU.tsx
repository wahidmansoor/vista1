import React from "react";

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="border rounded-lg shadow-sm mb-6">
    <div className="bg-green-50 px-4 py-2 font-semibold text-green-800 border-b">{title}</div>
    <div className="p-4 text-sm">{children}</div>
  </div>
);

const CDU = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Chemotherapy Day Unit (CDU)</h2>

      <Section title="1. Treatment Protocols">
        <p>Select cancer type to view sample protocols:</p>
        <ul className="list-disc ml-6 mt-2">
          <li><strong>Breast Cancer:</strong> AC → T (Doxorubicin + Cyclophosphamide → Paclitaxel)</li>
          <li><strong>Colon Cancer:</strong> FOLFOX (5-FU + Leucovorin + Oxaliplatin)</li>
          <li><strong>Lymphoma:</strong> ABVD (Adriamycin, Bleomycin, Vinblastine, Dacarbazine)</li>
        </ul>
      </Section>

      <Section title="2. Toxicity in Oncology">
        <p>Common adverse effects with grading reference (CTCAE):</p>
        <ul className="list-disc ml-6 mt-2">
          <li><strong>Grade 1:</strong> Mild nausea, no antiemetic required</li>
          <li><strong>Grade 2:</strong> Moderate diarrhea, oral meds needed</li>
          <li><strong>Grade 3:</strong> Febrile neutropenia, hospitalization</li>
          <li><strong>Grade 4:</strong> Life-threatening — ICU support</li>
        </ul>
        <p className="mt-2 italic text-gray-500">*Refer to CTCAE v5.0 for complete grading details*</p>
      </Section>

      <Section title="3. Premedications">
        <p>Supportive meds based on emetogenicity:</p>
        <ul className="list-disc ml-6 mt-2">
          <li><strong>High risk:</strong> Aprepitant + Dexamethasone + Ondansetron</li>
          <li><strong>Moderate:</strong> Dexamethasone + Ondansetron</li>
          <li><strong>Low:</strong> Dexamethasone or Ondansetron only</li>
        </ul>
      </Section>

      <Section title="4. Calculations">
        <ul className="list-disc ml-6">
          <li><strong>BSA (DuBois):</strong> √[(height(cm) × weight(kg))/3600]</li>
          <li><strong>AUC Dosing:</strong> Dose = AUC × (GFR + 25)</li>
          <li><strong>Creatinine Clearance (CrCl):</strong> Cockcroft-Gault formula</li>
        </ul>
        <p className="mt-2 italic text-gray-500">*Interactive calculators coming soon*</p>
      </Section>
    </div>
  );
};

export default CDU;
