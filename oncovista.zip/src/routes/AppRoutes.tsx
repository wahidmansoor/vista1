import LandingPage from "../pages/LandingPage";
import { Routes, Route } from "react-router-dom";
import Handbook from "../modules/handbook/Handbook";
// ... other pages

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/handbook" element={<Handbook />} />
      <Route path="/" element={<LandingPage />} />
      {/* Add other module routes */}
    </Routes>
  );
};

export default AppRoutes;
