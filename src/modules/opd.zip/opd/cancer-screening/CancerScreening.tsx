export default function CancerScreening() {
  return (
    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
      <li>Colonoscopy ≥50y or family history</li>
      <li>Mammogram ≥40y females</li>
      <li>PSA in males ≥50y (if relevant)</li>
    </ul>
  );
}
