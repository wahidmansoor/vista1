// QuickAssessment.tsx
// Progressive symptom questionnaires (stub for Phase 3)
import React from "react";
const QuickAssessment: React.FC = () => <div>Quick Assessment (coming soon)</div>;
export default QuickAssessment;
