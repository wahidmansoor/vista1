// SymptomScales.tsx
// Interactive symptom scales (stub for Phase 3)
import React from "react";
const SymptomScales: React.FC = () => <div>Symptom Scales (coming soon)</div>;
export default SymptomScales;
