Legacy symptom control files (SymptomControl.tsx, SymptomControlNew.tsx, and related components/data) have been removed. The new entry point is SymptomControlAssistant.tsx.

Please update all imports and routes to use SymptomControlAssistant instead of the old components.
