// SymptomControlAssistant.tsx
// Stateless, on-demand symptom guidance assistant for palliative care
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Copy, Printer, ArrowLeft } from "lucide-react";
import SymptomSearch from "./components/SymptomSearch";
import { symptomTemplates } from "./data/SymptomData";
import type { SymptomTemplate, Intervention } from "@/types/symptoms";
import { Separator } from "@/components/ui/separator";

const SymptomControlAssistant: React.FC = () => {
  const [selected, setSelected] = useState<import("./data/SymptomData").SymptomTemplate | null>(null);

  const handleCopy = () => {
    if (!selected) return;
    const text = `Symptom: ${selected.name}\n\nDescription: ${selected.description || "-"}\n\nPharmacological Interventions:\n${selected.interventions?.pharmacological.map(i => `- ${i.name}: ${i.dosing || ""} ${i.description ? `(${i.description})` : ""}`).join("\n") || "-"}\n\nNon-Pharmacological Interventions:\n${selected.interventions?.nonPharmacological.map(i => `- ${i.name}: ${i.description || ""}`).join("\n") || "-"}`;
    navigator.clipboard.writeText(text);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!selected) {
    return (
      <div className="max-w-2xl mx-auto p-6" role="region" aria-labelledby="symptom-assistant-title">
        <Card className="bg-muted text-muted-foreground dark:bg-zinc-900 dark:text-zinc-100 shadow-md p-6">
          <CardHeader className="p-0 mb-4">
            <CardTitle id="symptom-assistant-title" className="text-2xl font-bold">Symptom Guidance Assistant</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <SymptomSearch
              onSelectSymptom={(template) => setSelected(template)}
              currentSymptoms={[]}
              aria-label="Search for symptoms"
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  // Helper for rendering interventions in a 3-column grid
  const renderInterventions = (arr: any[], type: 'pharmacological' | 'nonPharmacological') => (
    <div className="grid grid-cols-3 gap-2 mt-2" role="region" aria-live="polite">
      <div className="font-semibold text-muted-foreground">Name</div>
      <div className="font-semibold text-muted-foreground">Dosing</div>
      <div className="font-semibold text-muted-foreground">Notes</div>
      {arr.map((i, idx) => (
        <React.Fragment key={i.name + idx}>
          <div className="text-sm font-medium text-zinc-900 dark:text-zinc-100" tabIndex={0}>{i.name}</div>
          <div className="text-xs text-muted-foreground" tabIndex={0}>{i.dosing || (type === 'pharmacological' ? '-' : '')}</div>
          <div className="text-xs text-muted-foreground" tabIndex={0}>{i.notes || i.description || '-'}</div>
        </React.Fragment>
      ))}
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto p-6" role="region" aria-labelledby="selected-symptom-title">
      <Card className="bg-muted text-muted-foreground dark:bg-zinc-900 dark:text-zinc-100 shadow-md p-6">
        <CardHeader className="p-0 mb-4">
          <CardTitle id="selected-symptom-title" className="text-2xl font-bold flex items-center gap-2">
            {selected.name}
            {selected.category && (
              <Badge className="ml-2 text-base px-3 py-1" variant="outline">{selected.category}</Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="space-y-6">
            <div className="text-xl font-bold mb-1">Description</div>
            <div className="mb-2 text-base text-muted-foreground" tabIndex={0}>{selected.description || "-"}</div>
            <Separator className="my-4" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8" role="region" aria-labelledby="pharm-section-title">
              <div tabIndex={0} aria-labelledby="pharm-section-title">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="default" className="w-fit">Pharmacological</Badge>
                </div>
                {selected.interventions?.pharmacological?.length ? (
                  renderInterventions(selected.interventions.pharmacological, 'pharmacological')
                ) : (
                  <div className="text-sm text-muted-foreground">No pharmacological interventions listed.</div>
                )}
              </div>
              <div tabIndex={0} aria-labelledby="nonpharm-section-title">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary" className="w-fit">Non-Pharmacological</Badge>
                </div>
                {selected.interventions?.nonPharmacological?.length ? (
                  renderInterventions(selected.interventions.nonPharmacological, 'nonPharmacological')
                ) : (
                  <div className="text-sm text-muted-foreground">No non-pharmacological interventions listed.</div>
                )}
              </div>
            </div>
            <Separator className="my-4" />
            <div className="flex flex-wrap gap-4 mt-2">
              <Button
                variant="outline"
                size="sm"
                aria-label="Back to Search"
                onClick={() => setSelected(null)}
                className="flex items-center gap-2 focus-visible:outline focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                <ArrowLeft className="w-5 h-5" /> Back to Search
              </Button>
              <Button
                variant="secondary"
                size="sm"
                aria-label="Copy All Recommendations"
                onClick={handleCopy}
                className="flex items-center gap-2 focus-visible:outline focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                <Copy className="w-5 h-5" /> Copy All Recommendations
              </Button>
              <Button
                variant="secondary"
                size="sm"
                aria-label="Print Recommendations"
                onClick={handlePrint}
                className="flex items-center gap-2 focus-visible:outline focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                <Printer className="w-5 h-5" /> Print Recommendations
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SymptomControlAssistant;
