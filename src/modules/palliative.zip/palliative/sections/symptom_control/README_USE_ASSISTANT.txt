Please use SymptomControlAssistant.tsx for all future symptom control logic. Legacy files are no longer present.
