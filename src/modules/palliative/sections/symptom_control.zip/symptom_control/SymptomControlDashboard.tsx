// SymptomControlDashboard.tsx
// Main entry point for the enhanced symptom management dashboard
import React, { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import SymptomOverview from "./Dashboard/SymptomOverview";
import ActiveSymptoms from "./Dashboard/ActiveSymptoms";
import SymptomTimeline from "./Dashboard/SymptomTimeline";
import InterventionTracker from "./Dashboard/InterventionTracker";
import SymptomScales from "./Assessment/SymptomScales";
import ESASAssessment from "./Assessment/ESASAssessment";
import BodyMap from "./Assessment/BodyMap";
import InterventionRecommendations from "./Interventions/InterventionRecommendations";
import MedicationManager from "./Interventions/MedicationManager";
import EffectivenessTracker from "./Interventions/EffectivenessTracker";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

const SymptomControlDashboard: React.FC = () => {
  const [search, setSearch] = useState("");
  // TODO: Integrate with context/provider for real symptom data

  return (
    <div className="max-w-7xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Symptom Management Dashboard</h1>
      <div className="mb-4 flex flex-col sm:flex-row gap-4">
        <Input
          type="text"
          placeholder="Search symptoms..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="sm:w-96"
          aria-label="Search symptoms"
        />
      </div>
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-4 flex flex-wrap">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="active">Active Symptoms</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="interventions">Interventions</TabsTrigger>
          <TabsTrigger value="assessment">Assessment Tools</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <SymptomOverview />
        </TabsContent>
        <TabsContent value="active">
          <ActiveSymptoms />
        </TabsContent>
        <TabsContent value="timeline">
          <SymptomTimeline />
        </TabsContent>
        <TabsContent value="interventions">
          <InterventionTracker />
          <InterventionRecommendations />
          <MedicationManager />
          <EffectivenessTracker />
        </TabsContent>
        <TabsContent value="assessment">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card><SymptomScales /></Card>
            <Card><ESASAssessment /></Card>
            <Card className="md:col-span-2"><BodyMap /></Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SymptomControlDashboard;
