✅ SymptomControlAssistant.tsx is now the only active symptom control component. All legacy files have been removed as per migration instructions.
