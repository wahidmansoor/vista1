All legacy symptom control files have been removed. SymptomControlAssistant.tsx is now the only supported component.
