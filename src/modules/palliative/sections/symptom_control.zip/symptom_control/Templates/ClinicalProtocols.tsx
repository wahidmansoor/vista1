// ClinicalProtocols.tsx
// Clinical protocol management (stub for Phase 4)
import React from "react";
const ClinicalProtocols: React.FC = () => <div>Clinical Protocols (coming soon)</div>;
export default ClinicalProtocols;
