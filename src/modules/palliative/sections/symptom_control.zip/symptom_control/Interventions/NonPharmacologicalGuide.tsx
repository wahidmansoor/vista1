// NonPharmacologicalGuide.tsx
// Non-pharmacological interventions (stub for Phase 4)
import React from "react";
const NonPharmacologicalGuide: React.FC = () => <div>Non-Pharmacological Guide (coming soon)</div>;
export default NonPharmacologicalGuide;
