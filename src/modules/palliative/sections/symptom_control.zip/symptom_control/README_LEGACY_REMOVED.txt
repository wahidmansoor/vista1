Legacy symptom control system removed. Please use SymptomControlAssistant.tsx for all symptom guidance.
