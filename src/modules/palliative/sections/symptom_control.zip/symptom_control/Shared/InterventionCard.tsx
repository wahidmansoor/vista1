// InterventionCard.tsx
// Reusable intervention card (stub for Phase 5)
import React from "react";
const InterventionCard: React.FC = () => <div>Intervention Card (coming soon)</div>;
export default InterventionCard;
