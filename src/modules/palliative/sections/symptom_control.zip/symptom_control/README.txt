SymptomControlAssistant.tsx is now the only supported symptom control component. All previous files have been removed.
